#define GDB_MULTI_ARCH 1
#include "solib.h"
