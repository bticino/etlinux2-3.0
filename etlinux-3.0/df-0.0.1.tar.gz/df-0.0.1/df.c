#include <sys/vfs.h>

int main(int argc, char **argv)
{
    struct statfs buf;
    statfs(".",&buf);
    printf(" bsize blocks   used  avail     inum  iused  ifree   filename\n");
    printf(" %5li %6li %6li %6li   %6li %6li %6li     %4li\n",
	   buf.f_bsize, buf.f_blocks, buf.f_blocks-buf.f_bfree,
	   buf.f_bavail, buf.f_files, buf.f_files-buf.f_ffree,
	   buf.f_ffree, buf.f_namelen);
    exit(0);
}
