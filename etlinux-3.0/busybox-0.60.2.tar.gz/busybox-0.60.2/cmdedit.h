#ifndef CMDEDIT_H
#define CMDEDIT_H

int     cmdedit_read_input(char* promptStr, char* command);

#endif /* CMDEDIT_H */
