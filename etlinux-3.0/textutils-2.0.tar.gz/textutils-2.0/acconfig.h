/* Definitions for GNU textutils, processed by autoheader.
   Copyright (C) 1995, 1997, 1998, 1999 Free Software Foundation, Inc.
*/

/* This is always defined.  It enables GNU extensions on systems that
   have them.  */
#ifndef _GNU_SOURCE
# undef _GNU_SOURCE
#endif
