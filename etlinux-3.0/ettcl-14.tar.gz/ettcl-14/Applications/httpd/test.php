<HTML>
<HEAD>
  <TITLE>Simple Sample PHP File</TITLE>
</HEAD>

<BODY>

<H1>Simple Sample PHP File</H1>

<p>Current time:

<EM><?echo date("D M d, Y H:i:s", time())?></EM>  </p>

</BODY>
</HTML>
