
/* a /dev/printk simplementation */

/* Copyright (c) 2003 Alessandro Rubini <rubini@linux.it> */
/* Licensed according to the GNU GPL, Version 2 or any later version */

#ifndef __KERNEL__
#  define __KERNEL__
#endif
#ifndef MODULE
#  define MODULE
#endif

#include <linux/config.h>
#include <linux/module.h>

#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/init.h>
#include <asm/uaccess.h>

MODULE_LICENSE("GPL");
EXPORT_NO_SYMBOLS;

#define DPK_BUF 1024
static char localbuf[DPK_BUF+1];

ssize_t dpk_write(struct file *filp, const char *ubuff, size_t count, loff_t *offp)
{
    int c;

    if (count > DPK_BUF) count = DPK_BUF;
    if (copy_from_user(localbuf, ubuff, count))
      return -EFAULT;
    c = count;
    /* remove possible trailing newline (and return), we add it ourselves */
    if (localbuf[c-1] == '\n') c--;
    if (localbuf[c-1] == '\r') c--;
    localbuf[c] = '\0';

    printk(KERN_INFO "%s\n", localbuf);
    return count;
}

struct file_operations dpk_fops = {
    .owner = THIS_MODULE,
    .write =    dpk_write,
};


struct miscdevice dpk_misc = {
    .minor = 68,
    .name = "printk",
    .fops = &dpk_fops,
};

int dpk_init(void)
{
    return misc_register(&dpk_misc);
}

void dpk_exit(void)
{
    misc_deregister(&dpk_misc);
}

module_init(dpk_init);
module_exit(dpk_exit);
