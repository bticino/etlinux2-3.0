extern char *mount_guess_rootdev(void);
