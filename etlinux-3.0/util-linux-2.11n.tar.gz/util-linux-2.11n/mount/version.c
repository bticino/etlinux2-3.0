#include "../defines.h"
char version[] = "mount-" UTIL_LINUX_VERSION;
