#if defined (__GNU_LIBRARY__) && __GNU_LIBRARY__ > 1
#include <crypt.h>
#endif
