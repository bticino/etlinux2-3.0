/* defined in cryptocard.c */
extern int cryptocard (void);

/* defined in login.c */
extern struct passwd *pwd;
extern int timeout;

