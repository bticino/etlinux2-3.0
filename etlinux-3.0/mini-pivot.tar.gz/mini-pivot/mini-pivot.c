/*
 * mini-pivot -- a do-it-all tool for pivot_root (with etlinux in mind)
 *
 * Copyright (C) 2003 Alessandro Rubini <rubini@linux.it>
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mount.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <linux/unistd.h>

_syscall2(int,pivot_root,const  char *,new_root,const char *,put_old)

extern int pivot_root(const char *new_root, const char *put_old);

#define BSIZE 4096
static char buffer[BSIZE];

volatile void second_pass(int argc, char **argv, char **envp);

int main(int argc, char **argv, char **envp)
{
    int i, fd0, fd1;
    char dirname[]="old-root-0"; /* must write to position 9 */
    char exename[]="-pivottmp0"; /* must write to position 9, too */

    if (argv[0][0] == '-')
	second_pass(argc, argv, envp);

    if (argc < 3) {
	fprintf(stderr, "%s: Use: \"%s <new-root> <new-init> [<arg> ...]\"\n",
		argv[0], argv[0]);
	exit(1);
    }
    
    if (chdir(argv[1])) {
	fprintf(stderr, "%s: can't chdir to %s: %s\n", argv[0], argv[1],
		strerror(errno));
	exit(1);
    }

    /* create a temporary directory to use as old root */
    for (i='a'; i<='z'; i++) {
	struct stat buf;
	dirname[9] = i;
	if (stat(dirname, &buf) < 0 && errno == ENOENT)
	    break;
    }
    if (mkdir(dirname, 0755)) { /* this catches the case i==32 too */
	fprintf(stderr, "%s: can't create a temporary directory in %s\n",
		argv[0], argv[1]);
	exit(1);
    }

    /* open a descriptor to yourself, used later */
    fd0 = open(argv[0],O_RDONLY);
    if (fd0 < 0) {
	fprintf(stderr, "%s: open(%s): %s\n", argv[0], argv[0],
		strerror(errno));
	exit(1);
    }

    /* now do the switch */
    if (pivot_root(argv[1], dirname)) {
	fprintf(stderr, "%s: pivot_root(): %s\n", argv[0], strerror(errno));
	rmdir(dirname);
	exit(1);
    }
    if (chroot(".")) {
	fprintf(stderr, "%s: chroot(): %s\n", argv[0], strerror(errno));
	exit(1);
    }

    /* create a file name for yourself*/
    for (i='a'; ; i++) {
	struct stat buf;
	exename[9] = i;
	if (stat(exename, &buf) < 0 && errno == ENOENT)
	    break;
    }

    /* copy yourself to the new filesystem */
    fd1 = creat(exename, 0777);
    if (fd1 < 0) {
	fprintf(stderr, "%s: open(%s): %s\n", argv[0], exename,
		strerror(errno));
	exit(1);
    }
    while (1) {
	i = read(fd0, buffer, BSIZE);
	if (i<=0) break;
	i = write(fd1, buffer, i);
    }
    if (i < 0) {
	fprintf(stderr, "%s: read(%s): %s\n", argv[0], argv[0],
		strerror(errno));
	exit(1);
    }
    close(fd0); close(fd1); sync();

    /* execute yourself */
    argv[0] = exename;
    argv[1] = dirname;
    execve(exename, argv, envp);
    fprintf(stderr, "%s: couldn't exec \"%s\"\n", argv[0], exename);
    exit(1);
}

/*
 * When we get here, we already are in the new root, also as executable image,
 * we only need to close the file descriptors and execute init
 *
 * argv[0] is this file, argv[1] is oldroot,
 */
volatile void second_pass(int argc, char **argv, char **envp)
{
    int i, fdtmp;

    fdtmp = open("/dev/console", O_RDWR);
    if (fdtmp < 0) {
	fprintf(stderr, "%s: can't open /dev/console: %s\n", argv[0],
	    strerror(errno));
	exit(1);
    }

    /* close all descriptors -- assume we don't have more than a few... */
    for (i=0; i<16; i++)
	close(i);
	
    /* open the console in the new filesystem -- we know it works */
    open("/dev/console", O_RDWR); dup(0); dup(0);
	
    /* open it once more, to report errors */
    stderr = fopen("dev/console", "w"); /* hack */
    
    /* unlink this file */
    if (unlink(argv[0])) {
	fprintf(stderr, "%s: unlink(%s): %s\n", argv[0], argv[0],
		strerror(errno));
    }
    
    /* umount the old root */
    if (umount(argv[1])) {
	fprintf(stderr, "%s: umount(%s): %s\n", argv[0], argv[1],
		strerror(errno));
    }

    /* close the extra descriptor */
    close(fileno(stderr));

    /* go.... */
    execve(argv[2], argv+2, envp);

    /* if we get here we surely have some errors, try to spit them out */
    stderr = fopen("dev/console", "w");
    fprintf(stderr, "%s: couldn't exec \"%s\"\n", argv[0], argv[2]);
    exit(1);
}
