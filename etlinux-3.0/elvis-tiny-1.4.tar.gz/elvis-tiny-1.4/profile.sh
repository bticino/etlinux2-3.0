set TERM=vt52
set SHELL=shell
